# Don't Remove Credit Tg - @VJ_Botz
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

import traceback
from pyrogram.types import Message
from pyrogram import Client, filters
from asyncio.exceptions import TimeoutError
from pyrogram.errors import (
    ApiIdInvalid,
    PhoneNumberInvalid,
    PhoneCodeInvalid,
    PhoneCodeExpired,
    SessionPasswordNeeded,
    PasswordHashInvalid
)
from config import API_ID, API_HASH, LOG_CHANNEL
from plugins.database import db

SESSION_STRING_SIZE = 351

@Client.on_message(filters.private & filters.command(["logout"]))
async def logout(client, message):
    sessions = await db.get_sessions(message.from_user.id)
    if not sessions:
        return await message.reply("**You are not logged in.**")
    
    keyboard = [
        [dict(text=f"Session {i+1}", callback_data=f"logout_{i}")]
        for i in range(len(sessions))
    ]
    
    await message.reply("**Select a session to logout:**", reply_markup={"inline_keyboard": keyboard})

@Client.on_callback_query(filters.regex("^logout_"))
async def logout_session(client, callback_query):
    index = int(callback_query.data.split("_")[1])
    sessions = await db.get_sessions(callback_query.from_user.id)
    
    if index >= len(sessions):
        return await callback_query.answer("Invalid session selected!", show_alert=True)
    
    await db.remove_session(callback_query.from_user.id, sessions[index])
    await callback_query.answer("Session logged out successfully!", show_alert=True)

    await client.send_message(LOG_CHANNEL, f"**User {callback_query.from_user.mention} logged out of a session.**")

@Client.on_message(filters.private & filters.command(["login"]))
async def login(bot: Client, message: Message):
    user_id = int(message.from_user.id)
    
    phone_number_msg = await bot.ask(chat_id=user_id, text="<b>Please send your phone number with country code.</b>")
    if phone_number_msg.text == '/cancel':
        return await phone_number_msg.reply('<b>Process cancelled!</b>')
    
    phone_number = phone_number_msg.text
    client = Client(":memory:", API_ID, API_HASH)
    await client.connect()
    
    await phone_number_msg.reply("Sending OTP...")
    try:
        code = await client.send_code(phone_number)
        phone_code_msg = await bot.ask(user_id, "Send the OTP in this format: `1 2 3 4 5`", filters=filters.text, timeout=600)
    except PhoneNumberInvalid:
        return await phone_number_msg.reply("`PHONE_NUMBER` **is invalid.**")
    
    if phone_code_msg.text == '/cancel':
        return await phone_code_msg.reply('<b>Process cancelled!</b>')
    
    try:
        phone_code = phone_code_msg.text.replace(" ", "")
        await client.sign_in(phone_number, code.phone_code_hash, phone_code)
    except (PhoneCodeInvalid, PhoneCodeExpired):
        return await phone_code_msg.reply('**Invalid or expired OTP.**')
    
    string_session = await client.export_session_string()
    await client.disconnect()
    
    if len(string_session) < SESSION_STRING_SIZE:
        return await message.reply('<b>Invalid session string</b>')
    
    await db.add_session(message.from_user.id, string_session)
    await bot.send_message(LOG_CHANNEL, f"**User {message.from_user.mention} logged in.**")
    
    await bot.send_message(message.from_user.id, "<b>Account Login Successfully.</b>")
