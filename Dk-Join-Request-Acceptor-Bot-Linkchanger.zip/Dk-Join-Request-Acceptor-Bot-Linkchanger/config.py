from os import environ

API_ID = int(environ.get("API_ID", "22207976"))
API_HASH = environ.get("API_HASH", "5c0ad7c48a86afac87630ba28b42560d")
BOT_TOKEN = environ.get("BOT_TOKEN", "7519708626:AAHZfGUAX0ANZOr4FanZqYONW8OBH8AWgG0")

# Make Bot Admin In Log Channel With Full Rights
LOG_CHANNEL = int(environ.get("LOG_CHANNEL", "-1002392460433"))
ADMINS = int(environ.get("ADMINS", "6872968794"))

# Warning - Give Db uri in deploy server environment variable, don't give in repo.
DB_URI = environ.get("DB_URI", "mongodb+srv://Test:Test@cluster0.pcpx5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0") # Warning - Give Db uri in deploy server environment variable, don't give in repo.
DB_NAME = environ.get("DB_NAME", "vjjoinrequetbot")

# If this is True Then Bot Accept New Join Request 
NEW_REQ_MODE = bool(environ.get('NEW_REQ_MODE', True))
